def map_column(data, column, func):
    return True

def sum_column(data, old_name, new_name):
    return True

def drop_column(data, columns_to_drop):
    return True

def add_column(data, column_name, func):
    return True